import re
from tqdm import tqdm
import csv
import codecs
from helper import *
import hashlib

filenamelist = getfilenamelist()

md5 = hashlib.md5()
for filename in filenamelist:
    newlines = []
    with codecs.open(filename+".cs", "r", encoding="utf-8-sig") as file:
        lines = file.readlines()
        i = 0
        for line in tqdm(lines):
            item = re.findall(r'this.AddRow\("([\s\S]*)"', line)       
            
            if(item):
                md5.update(item[0].encode('utf-8'))
                for words in item:
                    if (is_ascii(words)):
                        newlines.append([md5.hexdigest(),words])
                        i += 1
        print(i)

    with codecs.open(filename+".csv", "w", encoding="utf-8-sig") as file:
        f_csv = csv.writer(file)
        i = 0
        for newline in newlines:
            i = i + 1
            f_csv.writerow(newline)
            

 
