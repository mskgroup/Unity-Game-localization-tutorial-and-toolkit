字体转换器fntxml_to_unityfnt ：
支持：（U4中的旧格式，font_raw，新格式TextMeshProFont，TMP_FontAsset以及类似于SDF的内容）
有时不必根据格式使用页面或chnl，主要是现在，一切都没有chnl。
在极少数情况下（可能是TextMeshProFont），如果自动搜索偏移不起作用，则需要通过-hand键后的字符数手动指定偏移
。其余的开关保留在程序的旧版本中，现在您已经可以说是不必要的了，并且使用自动搜索更容易位移。
对于具有整数数据类型的较旧U4格式，使用-cordint开关
此类文件会自动启用对font_raw格式的支持，或通过-font_raw强制启用。您
可以通过从接收到的坐标值中提取export_UnityToFNT（-unitytofnt）或info_UnityData（-info）来找到正确的设置。
可以使用-plus开关以指定的值来调整坐标。
使用-k
-svad [value] 开关禁用添加字距列表，您可以指定坐标以哪个字符开头，默认情况下有一个空格字节32值，该值在自动搜索模式下使用。
-sbtn1 [value]值名字后要跳过多少字节，要考虑到对齐4，以切换到字符数。
-sbtn2 [value] value第二个名称后要跳过多少字节，要考虑到对齐4，以切换到字符数。
其余设置可在程序中找到。
使用控制台模式，可以将该程序用作破解程序中的修补程序，因为在游戏的每次更新部分字节更改后，旧文件将不再适合新版本，因此您需要重新滚动坐标。
该软件可能难以使用，因为大多数情况下，您需要以十六进制使用文件坐标视图，并通过字符数指示偏移量。如果适合使用自动搜索，则导出应获取普通类型的fnt文件，那么至少您需要了解它们的外观，好吧，通常它们应该是偶数，好像值应该不会跳太多。所选的批处理文件已经具有相同的参数，但是在导入时，它用于将已创建的字体回写到带有ru字母的BMFont中。但是大多数情况下，格式几乎在每个游戏中都在不断变化，并且如果不了解非常标准的类型需要应用哪些设置，就不太可能解决问题。此外，在Unity 2019中，甚至出现了非常复杂的格式以进行解析（它们以带有一组字符的单独表的形式出现，并指向它们的链接的坐标中。


Parser_ULS解析器：
用于 以csv格式使用 LanguageSource或LanguageSourceAsset 提取和打包I2Language的文本，  格式为
https://yadi.sk/d/Lz3SBVVFU7OJdg
一个小小的减法是手动指定-o开关后的行数，以及来自这些格式上限的差异。基本上，偏差就足够了（-d始终为2）。
注意，对于LanguageSourceAsset，几乎总是使用-o $ 0C偏移量，-d可以从2到4变化。


unPacker_CSV：
Packer解压缩程序，用于为Parser_ULS 提取和打包csv文本


Parser_UnityMDcpp2txt解析器：
用于提取和打包global-metadata.dat的文本


EXTRACT_TextBIN：
从MonoBehaviour（guishnaya）中提取文本
该程序功能强大，但没有描述，请向我解释所有特定设置，默认情况下，该设备似乎一切正常。
我只能说垃圾中有一些公认的单行为文本。
没有字母的golimotny。提取和插入格式是简单的txt，如ParserTextBinUnity包装器中那样。
好吧，用于文本的打包程序拆包器SpliteCombiner在这里，所以所有这些都放在一个文件-p中收集-u进行反汇编。

ParserTextBinUnity打包
MonoBehaviour文本并支持旧的本地化文件（控制台）
该程序功能强大，但没有描述，我可以破坏所有特定的设置，已经创建了批处理文件。
他们是为自己写的。我不知道他们对用户有多方便。


