﻿namespace AssetsAdvancedEditor.Plugins
{
    public interface IPlugin
    {
        public PluginInfo Init();
    }
}
