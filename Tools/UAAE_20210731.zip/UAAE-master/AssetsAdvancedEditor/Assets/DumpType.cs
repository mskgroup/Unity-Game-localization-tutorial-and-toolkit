﻿namespace AssetsAdvancedEditor.Assets
{
    public enum DumpType
    {
        TXT,
        XML,
        JSON
    }
}
