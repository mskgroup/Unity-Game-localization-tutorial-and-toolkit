﻿using System.Windows.Forms;
using AssetsTools.NET;
using AssetsTools.NET.Extra;

namespace AssetsAdvancedEditor.Winforms
{
    public partial class TextureViewer : Form
    {
        public TextureViewer(byte[] texData)
        {
            InitializeComponent();
            // todo
        }

        public TextureViewer(AssetsFileInstance fileInst, AssetTypeValueField baseField)
        {
            // todo
        }
    }
}
