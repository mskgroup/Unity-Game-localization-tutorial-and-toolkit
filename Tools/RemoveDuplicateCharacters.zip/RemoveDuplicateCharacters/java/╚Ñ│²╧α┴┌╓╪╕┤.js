public void initJava(){
        String str="aabbbccccdddddeeeeeeeeefff234tttdddfffbbbggg";
        String result=removeRepeatChar(str);
        Log.d("TAG","去重前----:"+str);
        Log.d("TAG","去重后----:"+result);
    }
 
    public String removeRepeatChar(String s) {
        if (s == null) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        int i = 0;
        int len = s.length();
        while (i < len) {
            char c = s.charAt(i);
            sb.append(c);
            i++;
            while (i < len && s.charAt(i) == c) {//这个是如果这两个值相等，就让i+1取下一个元素
                i++;
            }
        }
        return sb.toString();
    }