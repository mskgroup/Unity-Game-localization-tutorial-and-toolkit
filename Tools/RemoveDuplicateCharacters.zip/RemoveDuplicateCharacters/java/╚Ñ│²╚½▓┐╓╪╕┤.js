public void initJava(){
        String str="aabbbccccdddddeeeeeeeeefff234tttdddfffbbbggg";
        removeMethod(str);
    }
 
    public void removeMethod(String s) {
        Log.d("TAG", "去重前----:" + s);
        StringBuffer sb = new StringBuffer();
        int len = s.length();
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (s.indexOf(c) ==s.lastIndexOf(c)) {//此字符第一次位置和最后位置一致 即肯定没有重复的直接添加
                sb.append(c);
            } else {//同理 次字符出现过多次
                int fristposition=s.indexOf(c);//次字符第一次出现的位置
                if(fristposition==i){//第一次出现的位置和当前位置一致 即第一次出现添加
                    sb.append(c);
                }
            }
        }
        Log.d("TAG", "去重后----:" + sb.toString());
    }